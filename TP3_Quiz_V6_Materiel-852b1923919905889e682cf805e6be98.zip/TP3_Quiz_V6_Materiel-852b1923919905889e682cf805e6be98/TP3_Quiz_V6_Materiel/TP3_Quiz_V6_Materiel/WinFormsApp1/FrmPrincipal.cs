﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;

namespace WinFormsApp1
{
    public partial class FrmPrincipal : Form
    {
        private BanqueQuestions BanqueQuestions = new BanqueQuestions();
        public FrmPrincipal()
        {
            InitializeComponent();
        }

       

        private void btnGenererQuiz_Click(object sender, EventArgs e)
        {
           

            // TODO FP 1 : Générer un quiz à partir de la banque de questions,
            // puis ouvrir le formulaire FrmQuiz.
           

        }
    }
}
