﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    internal class QuestionReponseUnique
    {
        public string BonneReponse { get; set; }

        public Categorie Categorie { get; set; }

        public string Enonce { get; set; }

        public List<string> Options { get; set; }

        public int Points { get; set; }

        public QuestionReponseUnique(
            string enonce,
            Categorie categorie,
            int points,
            string bonneReponse,
            List<string> options)
        {
            Enonce = enonce;
            Categorie = categorie;
            Points = points;
            BonneReponse = bonneReponse;
            Options = options;
        }

        public double CorrigerReponse(string reponse)
        {
            return ValiderReponse(reponse) ? Points : 0;
        }

        public bool ValiderReponse(string reponse)
        {
            return reponse == BonneReponse;
        }

        public void MelangerOptions()
        {
            Random random = new Random();

            for (int i = 0; i < Options.Count; i++)
            {
                int j = random.Next(Options.Count);

                string temp = Options[i];
                Options[i] = Options[j];
                Options[j] = temp;
            }
        }
    }
}
