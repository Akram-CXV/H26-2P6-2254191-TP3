﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    internal class QuestionReponseCourte
    {
        public string BonneReponse { get; set; }

        public Categorie Categorie { get; set; }

        public string Enonce { get; set; }

        public int Points { get; set; }

        public QuestionReponseCourte(
            string enonce,
            Categorie categorie,
            int points,
            string bonneReponse)
        {
            Enonce = enonce;
            Categorie = categorie;
            Points = points;
            BonneReponse = bonneReponse;
        }

        public double CorrigerReponse(string reponse)
        {
            return ValiderReponse(reponse) ? Points : 0;
        }

        public bool ValiderReponse(string reponse)
        {
            return reponse.Trim().ToLower() ==
                   BonneReponse.Trim().ToLower();
        }
    }
}
