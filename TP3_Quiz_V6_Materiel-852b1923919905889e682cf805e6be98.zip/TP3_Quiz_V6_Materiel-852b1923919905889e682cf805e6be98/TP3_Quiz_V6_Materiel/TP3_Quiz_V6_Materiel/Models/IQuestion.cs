﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    internal interface IQuestion
    {
        Categorie Categorie { get; }

        string Enonce { get; }

        int Points { get; }

        double CorrigerReponse(string reponse);

        bool ValiderReponse(string reponse);
    }
}
