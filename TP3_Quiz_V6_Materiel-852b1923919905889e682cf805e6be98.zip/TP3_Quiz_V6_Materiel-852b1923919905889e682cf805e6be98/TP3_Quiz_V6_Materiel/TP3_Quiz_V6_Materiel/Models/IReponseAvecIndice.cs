﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    internal interface IReponseAvecIndice
    {
        string Indice { get; }

        bool IndiceUtilise { get; }

        double PenaliteIndice { get; }

        void UtiliserIndice();
    }
}
